from myprogram.utils import menu


def get_program_context(request):
    return {'mainmenu': menu}
