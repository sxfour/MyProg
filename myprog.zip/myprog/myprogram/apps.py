from django.apps import AppConfig


class MyprogramConfig(AppConfig):
    verbose_name = 'Моя программа'
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'myprogram'
